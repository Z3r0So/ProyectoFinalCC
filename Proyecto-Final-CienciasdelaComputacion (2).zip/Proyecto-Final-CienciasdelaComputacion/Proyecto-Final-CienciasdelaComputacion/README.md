# Proyecto Final - Ciencias de la Computacion

<p align="center">
  <img src="docs/images/MultilistaRegionesCiudades.png" alt="Multilista de regiones y ciudades">
</p>

<p align="center">
  <img src="docs/images/ArbolAVLCiudades.png" alt="Arbol AVL de ciudades">
</p>

<p align="center">
  <img src="docs/images/ListaDoblesCandidatosyAlcaldia.png" alt="Lista doble de candidatos y alcaldia">
</p>

<p align="center">
  <img src="docs/images/ArbolAVLCandidatos.png" alt="Arbol AVL de candidatos">
</p>

<p align="center">
  <img src="docs/images/ArregloDuo.png" alt="Arreglo duo">
</p>

<p align="center">
  <img src="docs/images/ArregloVotos.png" alt="Arreglo de votos">
</p>

<p align="center">
  <img src="docs/images/EstadisticasPartido.png" alt="Estadisticas del partido">
</p>

<p align="center">
  <img src="docs/images/FlujoEstructuradeDatos.png" alt="Flujo de la estructura de datos">
</p>
